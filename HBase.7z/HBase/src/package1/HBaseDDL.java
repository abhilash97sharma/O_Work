package package1;

import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.conf.Configuration;
import java.io.*;

public class HBaseDDL {
	
  public static void main(String[]args) throws IOException{
	  Configuration config = HBaseConfiguration.create();
	  config.set("hbase.zookeeper.quorum","quickstart.cloudera");
	  config.set("hbase.zookeeper.property.clientPort","2181");
	  config.set("hbase.master.port", "60000");
	  config.set("hbase.regionserver.thrift.port", "9090");
	//  config.set("hbase.rest.port", "20550");
	 // config.set("quickstart.cloudera", "60000");
	  
	  Connection conn = ConnectionFactory.createConnection(config);
      Admin hAdmin = conn.getAdmin();
      System.out.println("Connected successfully");
      //Object of the HTableDescriptor 
	  HTableDescriptor des = new HTableDescriptor(TableName.valueOf("emp"));
	  
	  HColumnDescriptor personel=new HColumnDescriptor("perosnal");
	  des.addFamily(new HColumnDescriptor(personel));
	  
	  HColumnDescriptor professional =new HColumnDescriptor("professional");
	  des.addFamily(new HColumnDescriptor(professional));
	  
	  System.out.println("Checkpoint 1");
	  hAdmin.createTable(des);
	  
/*	  if(hAdmin.tableExists(TableName.valueOf("emp"))) {
		  System.out.println("Table already exists");
		  System.out.println("Checkpoint 2");
	  }
	  else {
		  hAdmin.createTable(des);
		  System.out.println("Table created");
		  System.out.println("Checkpoint 3");
	  }*/
  }
  
}
