package hdfs.hive;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import org.apache.hive.*;

public class Hive_Sink {
	  private static String driverName = "org.apache.hive.jdbc.HiveDriver";
	  public static void main(String[]args) {
		try {  
			 Class.forName(driverName);
			 System.out.println("Driver registered successfully");
		      
		      // get connection
		      // Connection con = DriverManager.getConnection("jdbc:hive://localhost:10001/test");
		      Connection con = DriverManager.getConnection("jdbc:hive2://192.168.5.94:10000/default");
		      // create statement
		      Statement stmt = con.createStatement();
		      System.out.println("Connection established");
		      
		      // execute statement
		      stmt.executeQuery("CREATE TABLE IF NOT EXISTS employee ( eid int, name String, salary String, destignation String) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n' STORED AS TEXTFILE");   
		      System.out.println("Table employee created.");
		      con.close();
		}
		catch(Exception e1) {
			System.out.println("Some error occured:"+e1.getMessage());
		}
	  }
}
