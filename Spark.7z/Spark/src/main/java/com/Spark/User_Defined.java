package com.Spark;

public class User_Defined {
	
  public static int myLength(String s) {
	  return s.length();
  }
  public static String mORF(String s2) {
	  String []s = s2.split("::");
	  return s[0];
  }
}
