package com.Spark;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.spark.sql.expressions.WindowSpec;
import org.apache.spark.sql.expressions.Window;
import org.apache.spark.sql.*;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.types.DataTypes;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Log_File_Analysis {
   public static void main(String[]args) {
	   SparkSession spark = new SparkSession.Builder().master("local").appName("Log_Files").getOrCreate();
	   
/*	   spark.udf().register("fun45", new UDF2<String,String,String>(){
	     	  public String call(String s1, String s2) throws Exception{
	     		  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	     		  int sec1 = sdf.parse(s1).getSeconds();
	     		  int sec2 = sdf.parse(s2).getSeconds();
	     		  return (sec1-sec2)+"";
	     	  }
	       },DataTypes.StringType);   */
	   
	   spark.udf().register("TimeStamp_diff", new UDF2<Timestamp,Timestamp,Long>(){

		@Override
		public Long call(Timestamp t1, Timestamp t2) throws Exception {
			// TODO Auto-generated method stub
			
			return (t1.getTime()-t2.getTime())/1000;
		}
		   
	   },DataTypes.LongType);
	   
	   List<Integer> lst1 = new ArrayList<Integer>();
	   Dataset<Row> df = spark.read().format("csv").option("delimiter","|").option("header", true).option("inferSchema",true).load("/home/abhilash/Files/airbnb_session_data.txt");
	   Dataset<Row> df1 = df.withColumn("ds", functions.to_date(functions.col("ds")));
	   Dataset<Row> df2 = df1.withColumn("Day", functions.dayofmonth(functions.col("ds")));
	   Dataset<Row> df3 = df2.withColumn("Hour", functions.hour(functions.col("ts_min")));
       Dataset<Row> df4 = df3.withColumn("Add_month", functions.add_months(functions.col("ts_min"), 3));   
       Dataset<Row> df5 = df4.withColumn("ts_min_lag",functions.lag(functions.col("ts_min"), 1).over(Window.orderBy(functions.col("ds"))));
       Dataset<Row> df6 = df5.withColumn("ts_min_lead", functions.lead(functions.col("ts_min"),1).over(Window.orderBy(functions.col("ds"))));
       Dataset<Row> df61 = df6.withColumn("Row_Num", functions.row_number().over(Window.orderBy("ds").partitionBy("id_visitor")));
       Dataset<Row> df62 = df61.groupBy(functions.col("id_visitor").alias("id_visitor1")).agg(functions.min("ts_min"));
       Dataset<Row> df63 = df61.groupBy(functions.col("id_visitor")).agg(functions.max("ts_max"));
       Dataset<Row> df64 = df62.join(df63, df62.col("id_visitor1").equalTo(df63.col("id_visitor")) , "inner").drop("id_visitor1");
       
       Dataset<Row> df65 = df64.withColumn("Diff_Seconds", functions.callUDF("TimeStamp_diff", functions.col("max(ts_max)"), functions.col("min(ts_min)")));
       
//     System.out.println(df62.count()+","+df63.count()+","+df64.count());
       
//     df62.write().format("csv").save("/home/abhilash/outputfile");
//     Long l1 = df61.select(functions.col("id_visitor")).count();
//     System.out.println(l1);
/*       List<Row>lst11 = df61.select(functions.col("did_search")).collectAsList();
       System.out.println(lst11);
       Iterator itr = lst11.iterator();
       
       while(itr.hasNext()) {
    	   int obj = (int)itr.next();
    	   System.out.println(obj);
       }*/
       
       
//     Dataset<Row> df7 = df6.withColumn("ts_min_lag", functions.col("ts_min_lag").cast(DataTypes.StringType));
//     Dataset<Row> df8 = df7.withColumn("ts_min_lead", functions.col("ts_min_lead").cast(DataTypes.StringType));
//     Dataset<Row> df9 = df8.withColumn("ts_min_lag", functions.when(functions.col("ts_min_lag").isNull(), 0).otherwise(functions.col("ts_min_lag")));
//     Dataset<Row> df10 = df9.withColumn("ts_min_lead", functions.when(functions.col("ts_min_lead").isNull(), 0).otherwise(functions.col("ts_min_lead")));
//     Dataset<Row> df11 = df10.withColumn("UDF123", functions.callUDF("fun45", functions.col("ts_min_lag"), functions.col("ts_min_lead")));
       
//     List<Row> lst = df4.select(functions.col("did_search")).collectAsList();
/*       Iterator itr = lst.iterator();
       while(itr.hasNext()) {
         String s = itr.next().toString();
         char []ch = s.toCharArray();
         int o1 = Integer.valueOf(ch[1]+"");
         lst1.add(o1);
         System.out.println(ch.length);
    //	 System.out.println(itr.next().toString());
       }
  */     
/*       Iterator itr1 = lst.iterator();
       Iterator itr2 = lst1.iterator();
       int v1 = 0;
       int cond = 0;
       int prev = 0;
       int next = 0;
       while(itr1.hasNext()) {
    	   if(v1 == 0) {
    		   prev = (int)itr1.next();
    		   continue;
    	   }
    	   else {
    		   while(itr2.hasNext()) {
    			 next = (int)itr2.next();  
    		     if(prev == next) {
    			   lst_out.add(cond);
    		     }
    		     prev = next;
    		    
    	   }
    	 }
    	   v1++;
       }*/
       
//	   df61.show(5, false);
//	   df62.show(5, false);
//	   df63.show(5, false);
	   df65.show(5, false);
//	   df61.printSchema();
   }
}
