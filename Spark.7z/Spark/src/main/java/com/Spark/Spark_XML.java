package com.Spark;

import java.util.Arrays;
import org.apache.spark.sql.*;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.functions.*;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.expressions.UserDefinedFunction;
import org.apache.spark.sql.types.DataTypes;

public class Spark_XML {
   public static void main(String[]args) {
	   SparkSession spark = new SparkSession.Builder().master("local").appName("Demo_Spark_XML").getOrCreate();
	   Dataset<Row> df = spark.read().format("com.databricks.spark.xml").option("rowTag","PubmedArticle").load("file:///home/abhilash/Downloads/pubmed19n0112.xml");     //"file:///home/abhilash/Downloads/pubmed19n0112.xml"

	   // hdfs://192.168.5.176:8020/user/root/husain/pubmed/*
	   // "file:///home/abhilash/Downloads/pubmed19n0112.xml"
	   //  df.printSchema();                                                                                                                                            
	   // creating spark udf
	     spark.udf().register("combineName", new UDF2<String,String,String>(){

			@Override
			public String call(String t1, String t2) throws Exception {
				// TODO Auto-generated method stub
				String []fstName = t1.split(",");
				String []LstName = t2.split(",");
				String s1 = new String();
				int len = fstName.length;
				for(int i=0;i<len;i++) {
					s1 = s1+fstName[i]+" "+LstName[i]+",";
				}
				return s1;
			}
	     },DataTypes.StringType);
	   //
	   Dataset<Row> df1 = df.select(functions.col("PubmedData.ArticleIdList.ArticleId._VALUE").as("ArticleID"),functions.col("MedlineCitation.MeshHeadingList.MeshHeading.DescriptorName"),functions.col("MedlineCitation.Article.Abstract.AbstractText._VALUE").as("Abstract_Text"),functions.col("MedlineCitation.Article.ArticleTitle"),functions.col("MedlineCitation.Article.AuthorList.Author.ForeName"),functions.col("MedlineCitation.Article.AuthorList.Author.LastName"));
	   Dataset<Row> df4 = df1.withColumn("Desc", functions.explode(functions.col("DescriptorName"))).drop(functions.col("DescriptorName"));
/*	   Dataset<Row> df6 = df4.withColumn("Desc1", functions.col("Desc").cast(DataTypes.StringType));
       Dataset<Row> df5 = df6.withColumn("Type", functions.split(functions.col("Desc1"), ",").getItem(0));
       Dataset<Row> df7 = df5.withColumn("Code", functions.split(functions.col("Desc1"), ",").getItem(2));
       Dataset<Row> df8 = df7.withColumn("Content", functions.split(functions.col("Desc1"), ",").getItem(3)).drop(functions.col("Desc1"));
	   Dataset<Row> df9 = df8.withColumn("Type", functions.regexp_replace(functions.col("Type"), "\\[", ""));
	   Dataset<Row> df10 = df9.filter(functions.col("Type").equalTo("Y")).drop(functions.col("Desc"));
	   Dataset<Row> df11 = df10.withColumnRenamed("_VALUE", "Abstract_Text");
	   Dataset<Row> df12 = df11.withColumn("Content",functions.regexp_replace(functions.col("Content"), "\\]$", ""));
	   Dataset<Row> df13 = df12.withColumn("ForeName", functions.col("ForeName").cast(DataTypes.StringType)).withColumn("ForeName", functions.regexp_replace(functions.col("ForeName"), "\\]$",""));
	   Dataset<Row> df14 = df13.withColumn("LastName",functions.col("LastName").cast(DataTypes.StringType)).withColumn("LastName", functions.regexp_replace(functions.col("LastName"), "\\[",""));
	   Dataset<Row> df15 = df14.select(functions.col("ArticleID"),functions.col("ArticleTitle"),functions.col("Abstract_Text"),functions.col("Type"),functions.col("Content"),functions.col("Code"),functions.col("ForeName"),functions.col("LastName"),functions.callUDF("combineName", functions.col("ForeName"),functions.col("LastName")));
       Dataset<Row> df16 = df15.withColumnRenamed("UDF:combineName(ForeName, LastName)","AuthorNames").withColumn("AuthorNames",functions.regexp_replace(functions.col("AuthorNames"), "\\,$","")).drop("ForeName","LastName");
*/     df4.show(15,false);
       System.out.println("rows in dataframe df1:"+df1.count()+",rows in dataframe df4:"+df4.count());
       df.printSchema();
   }
}
