package com.Spark;

import org.apache.spark.sql.*;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.types.DataTypes;

public class Sample_UseCase {
     public static void main(String[]args) {
   	   SparkSession spark = new SparkSession.Builder().master("local").appName("Sample_File").getOrCreate();
  	   Dataset<Row> desc = spark.read().format("csv").load("file:///home/abhilash/sample_file_use_case.txt");     //"file:///home/abhilash/Downloads/pubmed19n0112.xml"
  	   Dataset<Row> country = spark.read().format("csv").load("file:///home/abhilash/country");
  	   
  	   //creating UDF 
  	   spark.udf().register("findMatch", new UDF1<String,String>(){
  		  public String call(String s1) throws Exception{
			String []country = {"India","USA","China"};
			for(String s: country) {
			  boolean out = s1.contains(s);
			  if(out)
				  return s;
			}
  			return null;
  		  }
  	   }, DataTypes.StringType);
  	   //
  	   
  	   Dataset<Row> df = desc.withColumn("Country", functions.callUDF("findMatch", functions.col("_c0")));
  	   df.show(100, false);
  	   
     }
}
