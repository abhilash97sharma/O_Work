package com.Spark;

import java.util.Arrays;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;

import scala.Tuple2;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.*;
import com.Spark.User_Defined;

public class RDD_Basics {
  public static void main(String[]args) {
	  SparkConf conf = new SparkConf().setAppName("RDD_Basics").setMaster("local");
	  JavaSparkContext context = new JavaSparkContext(conf);
	  JavaRDD<String> mov_rdd = context.textFile("/home/abhilash/Downloads/ml-1m/movies.dat");
	  JavaRDD<String> rat_rdd = context.textFile("/home/abhilash/Downloads/ml-1m/ratings.dat");
	  JavaRDD<String> user_rdd = context.textFile("/home/abhilash/Downloads/ml-1m/users.dat");
	  JavaRDD<String> rdd1 = mov_rdd.filter(a -> a.contains("Comedy"));
	  JavaPairRDD<String,String> rdd4_user = user_rdd.mapToPair(w1 -> new Tuple2<String,String>(User_Defined.mORF(w1),w1));
      JavaPairRDD<String,String> rdd5_rat = rat_rdd.mapToPair(w1 -> new Tuple2<String,String>(User_Defined.mORF(w1),w1));
//	  JavaPairRDD<String,String> rdd5 = rdd4.groupByKey();
//	  JavaPairRDD<String,String> rdd7 = rdd4.sortByKey();  //working
	 
	  // countByKey is returning a Map interface in the form of key-value pair.
	  Map<String, Long> rdd8 = rdd4_user.countByKey();  //working
	  // It returns map
	  
	  Function<Tuple2<String,String>, Boolean> lng =
			  new Function<Tuple2<String,String>, Boolean>(){
        	 public Boolean call(Tuple2<String, String> keyval) {
        		 return keyval._1.equals("M");
        	 }
	  };
	  
	  JavaPairRDD<String,String> rdd6 = rdd4_user.filter(lng);
	  
//	  JavaRDD<Integer> rdd3 = rdd1.map(new MyFunctionClass());
//	  JavaRDD<String> rdd4 = user_rdd.map(r1 -> r1.split("::"));
//	  JavaPairRDD<String,String> user_rat_join = rdd4_user.join(rdd5_rat);
	  System.out.println(rdd8);
	  System.out.println(rdd4_user.take(4));
	  System.out.println(rdd5_rat.take(4));
//	  JavaRDD<String> rdd2 = rdd1.flatMap(s -> Arrays.asList(s.split("::")).iterator());
//	  JavaPairRDD<String,Integer> rdd2 = rdd1.mapToPair(s -> new Tuple2<String,Integer>(s,1));
//	  System.out.println("Total no of records in movies table:"+rdd.count());
//	  rdd3.saveAsTextFile("/home/abhilash/Desktop/rddfile3");
//	  rdd1.saveAsTextFile("/home/abhilash/Desktop/rddfile1");
//	  System.out.println(rdd2.collect());
//	  JavaRDD<Object> rdd4=rdd1.map(a -> a.split("::"));
//	  rdd4.saveAsTextFile("/home/abhilash/Desktop/rddfile123");
//	  JavaRDD<Integer> mov_rdd1 = mov_rdd.map(a1 -> a1.length());
//	  mov_rdd1.saveAsTextFile("/home/abhilash/Downloads/ml-1m/rddfile123");
//	  rat_rdd.saveAsTextFile("/home/abhilash/Downloads/ml-1m/rddfile23");
	   
  }
}
